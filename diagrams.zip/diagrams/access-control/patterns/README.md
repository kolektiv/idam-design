# Patterns

High level overview diagrams of the patterns defined as part of the IdAM HLSA.
